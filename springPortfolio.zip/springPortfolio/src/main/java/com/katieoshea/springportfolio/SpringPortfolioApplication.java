package com.katieoshea.springportfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPortfolioApplication.class, args);
	}
}
