$(document).ready(function () {
    
    $(".column").hover(function () {
    	$( this ).toggleClass( "active" );   
    })

})