var express = require('express'),
    path = require('path'),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose');
var app = express(); 

app.use(express.json());
app.use(express.static(__dirname+"/restfulAngular/dist")); // for the angular app

mongoose.connect("mongodb://localhost/taskapi");
mongoose.Promise = global.Promise;

mongoose.model("Task", new mongoose.Schema({
        title: { type: String, required: true, minlength: 1, maxlength: 255},
        description: { type: String, default: "", minlength: 1, maxlength: 255},
        completed: { type: Boolean, default: false}
    }, {timestamps: true} 
));
var Task = mongoose.model("Task");

app.get("/tasks", function(req, res) { 
    console.log("hhihihihi");             //retrieve all tasks GET
    Task.find({}, (err, tasks)=> {
        if(err) {
            console.log("error loading all tasks");     
            res.json({message: "Error", error: err})       
        }
        else {
            console.log("yo"+tasks);             //retrieve all tasks GET
            
            res.json(tasks);
        }
    })
})
app.post("/tasks", function(req, res) {             // create new task POST
    let newTask = new Task(req.body);
    newTask.save(function(err) {
        if(err) {
            console.log("error saving newTask");
            res.json({message: "Error", error: err})
        }
        else {
            res.redirect("/tasks");        
        }
    }) 
})
app.get("/tasks/:id", function(req, res) {          // retrieve 1 task with :id GET
    Task.find({_id: req.params.id}, (err, task)=> {
        if(err) {
            console.log("error finding task");
            res.json({message: "Error", error: err})
        }
        else {
            res.json({message: "Success", data: task});            
        }
    })
})
app.put("/tasks/:id", function(req, res) {          // update 1 task with the :id PUT          
    Task.update({_id: req.params.id}, req.body, function(err) { //update functions has second argument!!
        if(err) {
            console.log("error updating task");
            res.json({message: "Error", error: err})
        }
        else {
            res.json("successful update");
            // res.redirect("/tasks");                    
        }
    });
})
app.delete("/tasks/:id", function(req, res) {       // delete 1 task with the :id DELETE
    Task.remove({_id: req.params.id}, (err)=> {
        if(err) {
            console.log("error finding task to delete");
            res.json({message: "Error", error: err})
        }
        else {            
            res.json("successful delete");
            // res.redirect("/tasks");                    
        }
    })
})


app.listen(6789, function() {
    console.log("listening on port 6789");
})