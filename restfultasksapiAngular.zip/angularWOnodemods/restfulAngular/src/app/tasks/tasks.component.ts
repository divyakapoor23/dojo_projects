import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  private tasks: any;
  constructor(private hserv: HttpService ) { }

  ngOnInit() {
    console.log("yolo");
    this.hserv.getTasks();
    // this.hserv.getTasks((data)=>{
    // this.tasks = data;
    // });
  
    //when this component is done loading, anything in here gets run-- generally queries
  }

}
