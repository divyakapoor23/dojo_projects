import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  private task: any;
  private tasks: any;
  private showtask:any;
  private taskId: any;
  constructor(private taskServ: TaskService) {
    
  }
  ngOnInit() {
    // this.all();
    this.task = {
      title: "",
      description: "",
      completed: false
    };
    this.taskId = ""
  }

  create() { 
    this.taskServ.create(this.task, (data)=>{ 
      console.log("Created this task", data);
    });
  }
  all() {
    this.taskServ.getTasks(data=>{
      this.tasks = data;
      console.log("Got our tasks!", data);
    });
  }
  show() {
    this.taskServ.show(this.taskId, (data)=>{
      this.showtask = data[0];
      console.log("Show this task", data[0]);
    });
  }

}
