package com.katieoshea.displayDates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Date;
import java.text.SimpleDateFormat;

@SpringBootApplication
public class DisplayDatesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisplayDatesApplication.class, args);
	}
	
	@Controller 
	public class DateTime {
		@RequestMapping("/")
		public String index() {
			return "index";
		}
		
		@RequestMapping("/date") 
		public String showdate(Model modeldate) {
			Date now = (Date) new java.util.Date();
			SimpleDateFormat dfdate = new SimpleDateFormat("EEEEE, 'the' d 'of' MMMMM, YYYY");
			String date = dfdate.format(now);
			modeldate.addAttribute("showdate", date);
			return "date";			
		}
		
		@RequestMapping("/time")
		public String showtime(Model modeltime) {
			Date now = (Date) new java.util.Date();
			SimpleDateFormat dfdate = new SimpleDateFormat("h:mm a");
			String time = dfdate.format(now);
			modeltime.addAttribute("showtime", time);
			return "time";
		}
	}
}
