from flask import Flask, render_template, request, redirect, flash, session
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX = re.compile(r'^[a-zA-Z]+$')
PASS_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]{8,}$')

app = Flask(__name__)
app.secret_key = "ceci n'est pas un secret"

@app.route('/')
def register():
    return render_template('form.html')

@app.route('/process', methods=["POST"])
def process_form():
    if len(request.form['email']) < 1 or len(request.form['first']) < 1 or len(request.form['last']) < 1 or len(request.form['password']) < 1 or len(request.form['confirm']) < 1:
        flash("Entries cannot be left blank!")
    if not EMAIL_REGEX.match(request.form['email']):
        flash("Invalid Email Address")
    if not NAME_REGEX.match(request.form['first']) or not NAME_REGEX.match(request.form['last']):
        flash("Invalid Name(s) - must be alpha characters only")
    if len(request.form['password']) < 8 or len(request.form['confirm']) < 8:
        flash("Your password must be at least 8 characters long.")
    if not PASS_REGEX.match(request.form['password']) or not PASS_REGEX.match(request.form['confirm']):
        flash("Invalid password")
    if request.form['password'] != request.form['confirm']:
        flash("Passwords do not match")
    else:
        email = request.form['email']
        first = request.form['first']
        last = request.form['last']
        password = request.form['password']
        confirm = request.form['confirm']
        flash("Thanks for submitting your information.")
    # print request.form
    return redirect('/')

app.run(debug=True)

# still not at ninja or hacker level :[ 2/10/18
# Ninja Version:
#     Add the validation that requires a password to have at least 1 uppercase letter and 1 numeric value.

# Hacker Version:
#     Add a birth-date field that must be validated as a valid date and must be from the past.