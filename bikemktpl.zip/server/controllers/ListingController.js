let Listing = require("mongoose").model("Listing");

class ListingController{
    all(req, res) { 
        Listing.find({}).populate({
            model:"User",
            path:"user"
        })
        .exec((err, listings)=> {
            if(err) {
                res.json({errors: "Failed to lookup listings."});
            }
            else {
                
                res.json(listings);
            }
        })
    }
    find(req, res) {
        Listing.findOne({_id: req.params.id})
        .populate({
            model:"User",
            path:"user"
        })
        .exec((err, listing)=> {
            if(err) {
                res.json({errors: "Failed to find listing."})
            }
            else {
                res.json(listing);            
            }
        })
    }
    create(req, res) {
        if(!req.session.userId) {
            return res.json({errors: "not logged in"})
        }
        let newListing = new Listing(req.body);
        newListing.user = req.session.userId; //add logged in user (must update both sides of the relationship!)
        newListing.save(function(err) {
            if(err) {
                res.json({errors: err});
            }
            else {
                User.findOne({_id: req.session.userId}, (err, user)=> {
                    user.listings.push(newListing); //add listings to array of listings
                    user.save((err=> {
                        if(err) {
                            res.json({errors: err});
                        }
                        else {
                            res.json(newListing);
                        }
                    }))
                })
            }
        }) 
    }
    update(req, res) {   
        // .update() function deprecated, not validating automatically, not changing updatedAt 
        // Listing.update({_id: req.params.id}, req.body, function(err) {
        //     if(err) {
        //         res.json({errors: err})
        //     }
        //     else {
        //         res.json({success: "Listing successfully updated"});                  
        //     }
        // });
        if(req.session.userId) { // can also put on front end...
            Listing.findOne({_id: req.params.id}, (err, listing)=> {
                if(err) {
                    res.json({errors: "Failed to find listing"});                    
                }
                else {
                    if(listing.user == req.session.userId) {
                        listing.title = req.session.title || listing.title; //never let something be null, keep the old info if the form is empty
                        listing.description = req.session.description || listing.description;
                        listing.price = req.session.price || listing.price;
                        listing.location = req.session.location || listing.location;
                        listing.src = req.session.src || listing.src;
                        // listing.updatedAt = new Date();
                        listing.save (err=> {
                            if(err) {
                                res.json({errors: err});
                            }
                            else {
                                res.json(listing);
                            }
                        })
                    }
                }
            })
        }
        else {
            res.json({errors: "You cannot update a listing that you did not create!"});

        }
    }
    destroy(req, res) {
        Listing.findOne({_id: req.params.id}, (err, listing)=> { //find first in case listing doesnt exist, and so you can retrieve it
            if(listing) {
                Listing.remove({_id: req.params.id}, (err)=> {
                    if(err) {
                        res.json({errors: "Error removing listing"})
                    }
                    else {     
                        // need to remove the listing from the user's list of listings too!       
                        res.json("Listing successfully removed", listing);                   
                    }
                })
            }
            else {
                res.json({errors: "Failed to find listing to remove"})
            }
        })

    }
}
module.exports = new ListingController(); 
