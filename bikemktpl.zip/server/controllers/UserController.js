let User = require("mongoose").model("User");
let bcrypt = require("bcrypt-nodejs");

class UserController{
    all(req, res) { 
        User.find({}, (err, users)=> {
            if(err) {
                res.json({errors: "Failed to retrieve users"});
            }
            else {
                res.json(users);
            }
        });
    }
    register(req, res) {
        User.findOne({email:req.body.email},(err,user)=>{
			if(user){
				return res.json({errors:"A user with this email already exists!"});
            }
            else{
                let newUser = new User(req.body);
                newUser.password = bcrypt.hashSync(req.body.password);
                let passcheck = bcrypt.compareSync(newUser.confirm, newUser.password);
                if(passcheck == true) {
                    newUser.save(err=>{
                        if(err) {
                            return res.status(403).json({errors:newUser.err}); //{errors:err}
                        }else{
                            req.session.userId = newUser._id; //auto login after register
                            return res.status(200).json(newUser);
                        }
                            })
                }
                else {
                    res.json({errors: "Password and Confirmation Password do not match"});
                }
			}
		});
    }
    login(req, res) {
        User.findOne({email: req.body.email})
        .populate({
            model:"Listing",
            path:"listings"
        })        
        .exec((err, user)=> {
            if(err) {
                res.json({errors: "Email not found. Please register."})
            }
            else {
                bcrypt.compare(req.body.password, user[0].password, function(err, result) {
                    if(err) {
                        res.json({errors: "Incorrect password"});
                    }
                    else {
                        req.session.user_id = user[0]._id;
                        res.json(user[0]);
                    }
                })
            }
        })
    }
    session(req, res) {
        if(req.session.userId) {
            User.findOne({_id:req.session.userId})
            .populate({
                model:"Listing",
                path:"listings"
            })
            .exec((err, user)=> {
                if(user) {
                    res.json(user);
                }
                else{
                    res.json({errors: err});
                }
            })
        }
        else {
            res.json(false);
        }
    }
}
module.exports = new UserController(); 
