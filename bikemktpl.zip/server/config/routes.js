let UserController = require("../controllers/UserController.js");
let ListingController = require("../controllers/ListingController.js");
let path = require('path'); //for app.all("**")

module.exports = function(app){
    // to test urls on Postman before going full MEAN
        // app.post("/api/register", UserController.register); 
        // app.post("/api/login", UserController.login); 
        // app.get("/api/listings", ListingController.all); 
        // app.post("/api/listings", ListingController.create); 
        // app.get("/api/listings/:id", ListingController.find); 
        // app.put("/api/listings/:id", ListingController.update); 
        // app.delete("/api/listings/:id", ListingController.destroy);         
        

    app.post("/register", UserController.register);
    app.post("/login", UserController.login);
    // app.get("/users", UserController.all);
    // app.post("/session", UserController.session);

    app.get("/listings", ListingController.all);
    app.get("/listings/:id", ListingController.find);
    app.post("/listings", ListingController.create);
    app.put("/listings/:id", ListingController.update);
    app.delete("/listings/:id", ListingController.destroy); 

    app.all("**", (request, response) => { response.sendFile(path.resolve("./client/dist/index.html")) });
    
}