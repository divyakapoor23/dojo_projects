import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { DailyBikeComponent } from './components/daily-bike/daily-bike.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UserActionsComponent } from './components/user-actions/user-actions.component';
import { CreateComponent } from './components/create/create.component';
import { MyListingsComponent } from './components/my-listings/my-listings.component';

import { UserService } from './services/user.service';
import { ListingService } from './services/listing.service';
import { ListingsComponent } from './components/listings/listings.component';

@NgModule({
  declarations: [
    AppComponent,
    LandingpageComponent,
    DashboardComponent,
    UserActionsComponent,
    CreateComponent,
    DailyBikeComponent,
    MyListingsComponent,
    ListingsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    UserService,
    ListingService
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }