import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UserActionsComponent } from './components/user-actions/user-actions.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', component: LandingpageComponent },
  { path: "browse", pathMatch: 'full', component: DashboardComponent },
  { path: "listings", pathMatch: 'full', component: UserActionsComponent },
  { path: '**', redirectTo: '' } //how to redirect to browse if logged in?
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
