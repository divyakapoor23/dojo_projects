import { Component, OnInit } from '@angular/core';
import { ListingService } from '../../services/listing.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-daily-bike',
  templateUrl: './daily-bike.component.html',
  styleUrls: ['./daily-bike.component.css']
})
export class DailyBikeComponent implements OnInit {
  private bike: any;
  constructor() { }

  ngOnInit() {
    this.randomBike();
  }
  randomBike() {

  }
  ngOnDestroy(): void {
    this.bike = null;
  }
}
