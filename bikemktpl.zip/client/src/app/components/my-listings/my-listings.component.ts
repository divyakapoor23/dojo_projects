import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ListingService } from '../../services/listing.service';

@Component({
  selector: 'app-my-listings',
  templateUrl: './my-listings.component.html',
  styleUrls: ['./my-listings.component.css']
})
export class MyListingsComponent implements OnInit {
  @Input() myListings;
  @Output() myEvent = new EventEmitter();

  private editbike: any;
  constructor(private listServ: ListingService) { }

  ngOnInit() {

  }
  update() {
    this.listServ.edit(this.editbike, (data)=> {
      this.editbike = data;
    })
  }
  destroy() {
    this.listServ.delete(this.editbike, (data)=> {
      console.log(data);
    })
  }
}
