import { Component, OnInit } from '@angular/core';
import { ListingService } from '../../services/listing.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  private user: any;
  private listings: any;
  constructor(private listServ: ListingService, private uServ: UserService) { }

  ngOnInit() {
    this.uServ.session((data)=>{
      this.user = data;
    })
    this.listServ.all((data)=> {
      this.listings = data;
    })
  }

}
