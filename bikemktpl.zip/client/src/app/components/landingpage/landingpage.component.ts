import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { ListingService } from '../../services/listing.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.css']
})
export class LandingpageComponent implements OnInit {
  private registering: any;
  private logging: any;

  constructor(private uServ:UserService, private route:ActivatedRoute, private router: Router) { 

  }

  ngOnInit() {
    this.registering={
      first: "",
      last: "",
      email: "",
      password: ""
    };
    this.logging= {
      email: "",
      password: ""
    };
  }

  register() {
    this.uServ.register(this.registering, (data=> {
      console.log(data); // should be user registering or errors
      this.registering= {
        email: "",
        password: ""
      };
      this.router.navigate(["/browse"]);

    }))
  }
  login() {
    this.uServ.login(this.logging, (data=> {
        console.log(data); // should be user logging in or errors
        this.logging= {
          email: "",
          password: ""
        };
        this.router.navigate(["/browse"]);
    }))
  }
}
