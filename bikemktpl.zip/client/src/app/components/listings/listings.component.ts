import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ListingService } from '../../services/listing.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-listings',
  templateUrl: './listings.component.html',
  styleUrls: ['./listings.component.css']
})
export class ListingsComponent implements OnInit {
  @Input() user;
  @Input() listing;
  
  constructor(private listServ: ListingService, private uServ: UserService) { }

  ngOnInit() {

  }
  destroy() {
    this.listServ.delete(this.listing, (data)=> {
      console.log(data);
    })
  }
  contact() {
    alert("Name: "+this.user.first+ " "+this.user.last+"\n Email: "+this.user.email);
  }

}
