import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ListingService } from '../../services/listing.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  @Input() myListings;
  @Output() myEvent = new EventEmitter();

  private newbike: any;
  constructor(private listServ: ListingService, private uServ: UserService) { }

  ngOnInit() {
    this.newbike = {
      title: "",
      description: "",
      price: 1,
      location: "",
      src: ""
    }
  }
  create() {
    this.listServ.create(this.newbike, (data=> {
      console.log(data);
      this.newbike = {
        title: "",
        description: "",
        price: 1,
        location: "",
        src: ""
      }
    }))
  }
}
