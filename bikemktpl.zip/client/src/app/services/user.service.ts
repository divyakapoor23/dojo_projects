import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";

@Injectable()
export class UserService {

  constructor(private http: HttpClient) { }

  register(user, cb) { 
    this.http.post("/users", user) 
    .subscribe(data=>cb(data)); 
  }   
  login(user, cb) { 
    this.http.post("/users", user) 
    .subscribe(data=>cb(data)); 
  } 
  session(cb) {
    this.http.get("/session")
    .subscribe(data=>cb(data)); 
  }
}
