var express = require('express'),
    path = require('path'),
    bodyParser = require('body-parser');
var app = express(); 

app.use(bodyParser.urlencoded({ extended: true })); //pulls out form data for our use
app.use(express.json()); 
app.use(express.static(__dirname+"/public/dist")); // for the angular app, __dirname+"/<angular app name>/dist"

require("./server/config/mongoose.js");
require("./server/config/routes.js")(app);

app.listen(6789, function() {
    console.log("listening on port 6789");
})