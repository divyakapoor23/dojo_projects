let mongoose = require("mongoose");  
    //ex: bcrypt, session...

let Task = mongoose.model("Task");

class TaskController{
    all(req, res) { 
        console.log("hhihihihi");
        Task.find({}, (err, tasks)=> {
            if(err) {
                // how to add a specific error code
                // 404 error-page not found, 403-page forbidden...etc.
                return res.status(404).json({message: "Error loading all tasks", error: err})       
            }
            else {
                console.log(tasks);
                res.json({message: "Success", data: tasks});
            }
        })
    }
    create(req, res) {
        let newTask = new Task(req.body);
        newTask.save(function(err) {
            if(err) {
                res.json({message: "Error saving new task", error: err})
            }
            else {
                res.redirect("/tasks");        
            }
        }) 
    }
    show(req, res) {
        Task.find({_id: req.params.id}, (err, task)=> {
            if(err) {
                res.json({message: "Error finding task", error: err})
            }
            else {
                res.json({message: "Success", data: task});            
            }
        })
    }
    edit(req, res) {         
        Task.update({_id: req.params.id}, req.body, function(err) {
            if(err) {
                res.json({message: "Error updating task", error: err})
            }
            else {
                res.json("Task successfully update");                  
            }
        });
    }
    delete(req, res) {
        Task.remove({_id: req.params.id}, (err)=> {
            if(err) {
                res.json({message: "Error finding task to delete", error: err})
            }
            else {            
                res.json("Task successfully delete");                   
            }
        })
    }
}
module.exports = new TaskController(); 
//**VERY IMPORTANT LINE OF CODE TO GET EVERYTHING TO WORK**