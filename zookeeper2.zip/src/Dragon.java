
public class Dragon {
	private int energyLevel;
	public Dragon () {
		this.energyLevel = 300;
	}
	public void setEnergyLevel(int newLev) {
		energyLevel = newLev;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int displayEnergy() {
		int level = this.getEnergyLevel();
		System.out.println(level);
		return level;
	}
	public void fly() {
		System.out.println("GGGGGGGRRRRRRZZZZZZZWHOOOOOSH!");
		int dEL = this.getEnergyLevel();
		this.setEnergyLevel(dEL-50);
	}
	public void eatHuman() {
		System.out.println("EEk! The Dragon ate a human!!");
		int dEL = this.getEnergyLevel();
		this.setEnergyLevel(dEL+25);
	}
	public void attackTown() {
		System.out.println("AAaAaaAAaaaaaAahhhHHHHhHhHh!!");
		int dEL = this.getEnergyLevel();
		this.setEnergyLevel(dEL-100);
	}
}
