
public class DragonTest {
	public static void main(String[] args) {
		Dragon Mushu = new Dragon();
		
		Mushu.attackTown();
		Mushu.attackTown();
		Mushu.attackTown();
		Mushu.eatHuman();
		Mushu.eatHuman();
		Mushu.fly();
		Mushu.fly();
		Mushu.displayEnergy();
	}
}
