
public class Gorilla extends Mammal{
	public Gorilla(){
		super();
	}
	public void throwSomething() {
		System.out.println("The Gorilla threw something!!");
		int gEL = this.getEnergyLevel();
		this.setEnergyLevel(gEL-5);
	}
	public void eatBananas() {
		System.out.println("The Gorilla ate a banana!!");
		int gEL = this.getEnergyLevel();
		this.setEnergyLevel(gEL+10);
	}
	public void climb() {
		System.out.println("The Gorilla climbed a tree!!");
		int gEL = this.getEnergyLevel();
		this.setEnergyLevel(gEL-10);
	}
}
