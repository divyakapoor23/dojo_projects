def findCharacters(word_list, char):
    new_list = []
    for x in range(len(word_list)):
        for letter in word_list[x]:
            if letter == char:
                new_list.append(word_list[x])
                break
    print new_list
findCharacters(['hello','book','world','my','name','is','Anna'], 'o')
