# Find and Replace
words = "It's thanksgiving day. It's my birthday,too!"
# print words
print words.find('day')

new = words.replace(' day', ' month')
print new

# day = words.replace('day', 'month')
# print day

# Min and Max
x = [2,54,-2,7,12,98]
print min(x) 
print max(x)

# First and last
x = ["hello",2,54,-2,7,12,98,"world"]
print x[0], x[-1]

# New List
x = [19,2,54,-2,7,12,98,32,10,-3,6]
# print x
x.sort()
# print x
new = x[0:(len(x)/2)]
# print new
other = x[(len(x)/2)-1:]
# print other
other[0] = new
print other
