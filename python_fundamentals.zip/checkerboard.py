star = "* * * * "
space = " * * * *"
for line in range(1,5):
    print star+"\n"+space