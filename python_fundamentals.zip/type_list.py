def listType(mylist):
    mystring = ""
    mysum = 0
    for element in mylist:
        countstr = 0
        countint = 0
        if type(element) == str:
            mystring = mystring + element + " "
            countstr += 1
        if type(element) == int:
            mysum += element
            countint += 1
    if countstr > 0 and countint > 0:
        print "The list you entered is of mixed type"    
        print "String: {}".format(mystring)
        print "Sum: {}".format(mysum)
    elif countstr > 0 and countint < 1:
        print "The list you entered is of string type"
        print "String: {}".format(mystring)
    else:
        print "The list you entered is of integer type"
        print "Sum: "+ mysum
listType(['magical unicorns',19,'hello',98.98,'world'])