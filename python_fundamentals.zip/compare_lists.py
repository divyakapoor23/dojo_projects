def comparing(list1, list2):
    if len(list1) != len (list2):
        print "The lists are not the same"
    else:
        for i in range(len(list1)):
            if list1[i] != list2[i]:
                print "The lists are not the same"
            else:
                if i != len(list1)-1:
                    continue
                else:
                    print "The lists are the same"
comparing([1,2,5,6,2], [1,2,5,6,2])
comparing([1,2,5,6,5], [1,2,5,6,5,3])
comparing([1,2,5,6,5,16], [1,2,5,6,5])
comparing(['celery','carrots','bread','milk'], ['celery','carrots','bread','cream'])