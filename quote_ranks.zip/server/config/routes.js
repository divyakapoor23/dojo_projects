let QuoteController = require("../controllers/QuoteController.js");
let AuthorController = require("../controllers/AuthorController.js");

let path = require('path'); //for app.all("**")

module.exports = function(app){
    app.get("/authors", AuthorController.all);
    app.post("/authors", AuthorController.create);
    app.get("/authors/:id", AuthorController.show);
    app.put("/authors/:id", AuthorController.update);
    app.delete("/authors/:id", AuthorController.destroy);

    app.get("/quotes", QuoteController.all);
    app.get("/quotes/:id", QuoteController.show);
    app.post("/quotes", QuoteController.create);
    app.put("/quotes/up/:id", QuoteController.upvote);
    app.put("/quotes/down/:id", QuoteController.downvote);
    app.delete("/quotes/:id", QuoteController.destroy); 

    app.all("**", (request, response) => { response.sendFile(path.resolve("./client/dist/index.html")) });
    
}