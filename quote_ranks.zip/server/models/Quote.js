let mongoose = require('mongoose');
let ObjectId = mongoose.Schema.Types.ObjectId;

mongoose.model("Quote", new mongoose.Schema({
    quote:{type:String, required:true, minlength:3, maxlength:255}, 
	votes:{ type:Number, default: 0 }, 
    author: {type:ObjectId, ref: "Author"}
    }, {timestamps: true} 
));