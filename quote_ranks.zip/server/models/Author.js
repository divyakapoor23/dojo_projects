let mongoose = require('mongoose');
let ObjectId = mongoose.Schema.Types.ObjectId;

mongoose.model("Author", new mongoose.Schema({
    name: { type:String, require: true, minlength: 3, maxlength: 255 },
    quotes:[{ type:ObjectId, ref:"Quote" }]
    }, {timestamps: true} 
));