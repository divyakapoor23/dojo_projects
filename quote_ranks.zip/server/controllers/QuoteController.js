let Quote = require("mongoose").model("Quote");

class QuoteController{
    all(req, res) { 
        Quote.find({}).populate({
            model:"Author",
            path:"author"
        })
        .exec((err, quotes)=> {
            if(err) {
                res.json({errors: "Failed to lookup quotes."});
            }
            else {
                res.json(quotes);
            }
        })
    }
    create(req, res) {
        let newQuote = new Quote(req.body);
        newQuote.author = req.params.authId;
        newQuote.save(function(err) {
            if(err) {
                res.json({errors: err});
            }
            else {
                Author.findOne({_id: req.params.authId}, (err, author)=> {
                    author.quotes.push(newQuote); 
                    author.save((err=> {
                        if(err) {
                            res.json({errors: err});
                        }
                        else {
                            res.json(newQuote);
                        }
                    }))
                })
            }
        }) 
    }
    show(req, res) {
        Quote.findOne({_id: req.params.id})
        .populate({
            model:"Author",
            path:"author"
        })
        .exec((err, quote)=> {
            if(err) {
                res.json({errors: "Failed to find quote."})
            }
            else {
                res.json(quote);            
            }
        })
    }
    upvote(req, res) {   
        // .update() function deprecated, not validating automatically, not changing updatedAt 
        // Quote.update({_id: req.params.id}, req.body, function(err, quote) {
        //     if(err) {
        //         res.json({errors: err})
        //     }
        //     else {
        //         res.json(quote);                  
        //     }
        // });
        Quote.findOne({_id: req.params.id}, (err, quote)=> {
            if(err) {
                res.json({errors: "Failed to find quote"});                    
            }
            else {
                quote.votes += 1; 
                quote.quote = quote.quote;
                quote.author = quote.author;
                quote.save (err=> {
                    if(err) {
                        res.json({errors: err});
                    }
                    else {
                        res.json(quote);
                    }
                })
            }
        })
    }
    downvote(req, res) {   
        Quote.findOne({_id: req.params.id}, (err, quote)=> {
            if(err) {
                res.json({errors: "Failed to find quote"});                    
            }
            else {
                quote.votes -= 1; 
                quote.quote = quote.quote;
                quote.author = quote.author;
                quote.save (err=> {
                    if(err) {
                        res.json({errors: err});
                    }
                    else {
                        res.json(quote);
                    }
                })
            }
        })
    }
    destroy(req, res) {
        Quote.findOne({_id: req.params.id}, (err, quote)=> { 
            if(quote) {
                Quote.remove({_id: req.params.id}, (err)=> {
                    if(err) {
                        res.json({errors: "Error removing quote"})
                    }
                    else {     
                        let author = quote.author;
                        for(let i=0; i < author.quotes.length; i++) {
                            if(author.quotes[i] == quote._id) {
                                author.quotes.splice(i);
                            }
                        }
                        author.save((err)=> {
                            if(err) {
                                res.json({errors: err});
                            }
                            else {
                                res.json(listing);
                            }                            
                        })
                    }
                })
            }
            else {
                res.json({errors: "Failed to find quote to remove"})
            }
        })
    }
}
module.exports = new QuoteController(); 
