let mongoose = require("mongoose");
let Author = mongoose.model("Author");

class AuthorController{
    all(req, res) { 
        Author.find({}, (err, authors)=> {
            if(err) {
                res.json({errors: "Failed to retrieve users"});
            }
            else {
                
                res.json(authors);
            }
        })
    }
    create(req, res) {
        let author = new Author(req.body);
        author.save(function(err) {
            if(err) {
                res.json({errors: err});
            }
            else {
                res.json(author);        
            }
        }) 
    }
    show(req, res) {
        Author.findOne({_id: req.params.id})
        .populate({
            model:"Quote",
            path:"quotes"
        })        
        .exec((err, author)=> {
            if(err) {
                return res.json({errors: err})
            }
            else {
                return res.json(author);            
            }
        })
    }
    update(req, res) { 
        // .update() function deprecated, not validating automatically, not changing updatedAt 
        // Author.update({_id: req.params.id}, req.body, function(err, author) {
        //     if(err) {
        //         res.json({errors: err})
        //     }
        //     else {
        //         res.json(author);                  
        //     }
        // });
        Author.findOne({_id: req.params.id}, (err, author)=> {
            console.log("bulbasaur", author)
            console.log("eevee", req.body)
            if(err) {
                console.log("meowth", err)
                res.json({errors: "Failed to find author"});                    
            }
            else {
                author.name = req.body.name || author.name; 
                author.quotes = author.quotes;
                // author.updatedAt = new Date();
                author.save (err=> {
                    if(err) {
                        res.json({errors: err});
                    }
                    else {
                        res.json(author);
                    }
                })
            }
        })
    }
    destroy(req, res) {
        Author.remove({_id: req.params.id}, (err)=> {
            if(err) {
                res.json({errors: "Error finding Author to delete"});
            }
            else {            
                res.json("Author successfully deleted");                   
            }
        })
    }
}
module.exports = new AuthorController(); 
