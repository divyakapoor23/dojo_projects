import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { AuthorService } from '../../services/author.service';

@Component({
  selector: 'app-edit-auth',
  templateUrl: './edit-auth.component.html',
  styleUrls: ['./edit-auth.component.css']
})
export class EditAuthComponent implements OnInit {
  private editAuth: any;
  private authId: any;
  private errors: any;
  constructor(private route:ActivatedRoute, private router: Router, private authServ: AuthorService) { 

  }

  ngOnInit() {
    this.route.params.subscribe((params: Params) => this.authId = params['authId']);
    this.find();
  }
  find(){
    this.authServ.show(this.authId, (data)=>{
      this.editAuth = data;
    });
  }
  edit() {
    this.authServ.update(this.editAuth, (data)=>{ 
      if(data.errors) {
        this.errors = data.errors;
        console.log("erorrrrrr");
      }
      else {
        this.router.navigate(["/quotes/"+this.authId]);        
      }
    });
  }
}
