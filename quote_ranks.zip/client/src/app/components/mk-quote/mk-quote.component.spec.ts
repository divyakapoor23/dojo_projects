import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MkQuoteComponent } from './mk-quote.component';

describe('MkQuoteComponent', () => {
  let component: MkQuoteComponent;
  let fixture: ComponentFixture<MkQuoteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MkQuoteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MkQuoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
