import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mk-quote',
  templateUrl: './mk-quote.component.html',
  styleUrls: ['./mk-quote.component.css']
})
export class MkQuoteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
