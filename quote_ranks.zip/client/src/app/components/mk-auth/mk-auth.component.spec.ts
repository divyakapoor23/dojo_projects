import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MkAuthComponent } from './mk-auth.component';

describe('MkAuthComponent', () => {
  let component: MkAuthComponent;
  let fixture: ComponentFixture<MkAuthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MkAuthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MkAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
