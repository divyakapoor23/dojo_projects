import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { AuthorService } from '../../services/author.service';

@Component({
  selector: 'app-mk-auth',
  templateUrl: './mk-auth.component.html',
  styleUrls: ['./mk-auth.component.css']
})
export class MkAuthComponent implements OnInit {
  private newAuth: any;
  
  constructor(private route:ActivatedRoute, private router: Router, private authServ: AuthorService) { }

  ngOnInit() {
    this.newAuth = { name: "" };
  }

  create() { 
    this.authServ.create(this.newAuth, (data)=>{ 
      this.newAuth = { name: "" };
      this.router.navigate(["/"]);
    });
  }
}
