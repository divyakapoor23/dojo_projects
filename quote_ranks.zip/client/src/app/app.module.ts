import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { AuthorsComponent } from './components/authors/authors.component';
import { QuotesComponent } from './components/quotes/quotes.component';
import { MkAuthComponent } from './components/mk-auth/mk-auth.component';
import { MkQuoteComponent } from './components/mk-quote/mk-quote.component';

import { AuthorService } from './services/author.service';
import { QuoteService } from './services/quote.service';
import { EditAuthComponent } from './components/edit-auth/edit-auth.component';

@NgModule({
  declarations: [
    AppComponent,
    AuthorsComponent,
    QuotesComponent,
    MkAuthComponent,
    MkQuoteComponent,
    EditAuthComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    AuthorService,
    QuoteService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
