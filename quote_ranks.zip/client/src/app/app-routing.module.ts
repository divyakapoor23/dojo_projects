import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthorsComponent } from './components/authors/authors.component';
import { QuotesComponent } from './components/quotes/quotes.component';
import { MkAuthComponent } from './components/mk-auth/mk-auth.component';
import { MkQuoteComponent } from './components/mk-quote/mk-quote.component';
import { EditAuthComponent } from './components/edit-auth/edit-auth.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', component: AuthorsComponent },
  { path: "new", pathMatch: 'full', component: MkAuthComponent },
  { path: "edit/:authId", pathMatch: 'full', component: EditAuthComponent },
  { path: "quotes/:authId", pathMatch: 'full', component: QuotesComponent },
  { path: "write/:authId", pathMatch: 'full', component: MkQuoteComponent },
  { path: '**', redirectTo: '' } //how to redirect to browse if logged in?
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
