import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";

@Injectable()
export class QuoteService {

  constructor(private http:HttpClient) { 

  }
  all(cb) {
    this.http.get("/quotes")
    .subscribe(data=>cb(data));
  }
  show(id, cb) {
    this.http.get("/quotes/"+id)
    .subscribe(data=>cb(data));
  }
  create(quote, cb) { 
    this.http.post("/quotes", quote) 
    .subscribe(data=>cb(data)); 
  } 
  update(quote, cb) { 
    this.http.put("/quotes/"+quote._id, quote) 
    .subscribe(data=>cb(data)); 
  } 
  destroy(quote, cb) {
    this.http.delete("/quotes/"+quote._id)
    .subscribe(data=>cb(data));
  }
}
