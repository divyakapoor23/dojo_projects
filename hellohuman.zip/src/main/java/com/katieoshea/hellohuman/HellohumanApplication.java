package com.katieoshea.hellohuman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@SpringBootApplication
public class HellohumanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellohumanApplication.class, args);
	}
	
	@Controller
	public class HelloHuman {
	    @RequestMapping("/")
	    public String index(@RequestParam(defaultValue="Human", value="name") String person, @RequestParam(defaultValue=" ", value="last_name") String last,Model model) {
	    	model.addAttribute("person", person);
	    	model.addAttribute("last", last);
	    	return "index.jsp";
		}
	}
}
