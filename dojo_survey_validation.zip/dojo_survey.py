from flask import Flask, render_template, request, redirect, flash, session
import re

NAME_REGEX = re.compile(r'^(\w+\S+)$')
COMMENT_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]{,120}$')
app = Flask(__name__)
app.secret_key = "Ceci n'est pas un secret"

@app.route('/')
def fill_survey():
    return render_template('dojo.html')

@app.route('/result', methods=["POST"])
def result():
    if len(request.form['name']) < 1 :
        flash("Name cannot be blank!")
    elif not NAME_REGEX.match(request.form['name']):
        flash("Invalid Name Entry!")
    if len(request.form['comment']) < 1:
        flash("Comment cannot be blank!")
    elif not COMMENT_REGEX.match(request.form['comment']):
        flash("Your Comment is too long!")
    # return redirect('/')
    else: 
        name = request.form['name']
        dojo = request.form['dojo']
        lang = request.form['lang']
        comment = request.form['comment']
        return render_template('results.html', name=name, dojo=dojo, lang=lang, comment=comment)

app.run(debug=True)