
public class BankAcctTest {
	public static void main(String[] args) {
		BankAccount alpha = new BankAccount(299.87, 4567.09);
		BankAccount beta = new BankAccount(657.09, 2004.56);
		BankAccount gamma = new BankAccount(1234.56, 32547.65);
        BankAccount delta = new BankAccount(86.45, 43.09);
        
        alpha.getAcctNum();
        beta.getAcctNum();
        gamma.getAcctNum();
        delta.getAcctNum();

        gamma.withdrawSAcct(3450.00);
        gamma.getSBal();

        alpha.depCAcct(567.43);
        alpha.withdrawCAcct(300.00);
        alpha.depSAcct(300.00);
        alpha.seeBals();

        beta.depCAcct(50.00);
        beta.getCBal();

        delta.withdrawCAcct(100.00);
        delta.withdrawSAcct(100.00);
        delta.seeBals();
	}
}
