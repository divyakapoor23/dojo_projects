from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string

def index(request):
    if 'attempt'  not in request.session:
        request.session['attempt'] = 1
    else:
        request.session['attempt'] += 1
    request.session['word'] = get_random_string(length=14)
    return render(request, 'random_word/index.html')
def generate(request):
    return redirect('/')
def reset(request):
    del request.session['attempt']
    del request.session['word']
    return redirect('/')