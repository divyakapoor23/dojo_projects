var mongoose = require("mongoose");

mongoose.model("User", new mongoose.Schema({
    email: {type:String, require:true, minlength:1, maxlength:255, unique: [true, "This email is already in use"]},
    first_name: {type:String, require:true, minlength:1, maxlength:255},
    last_name: {type:String, require:true, minlength:1, maxlength:255},
    birthday: {
        type: String,
        validate: [{
                validator: function( number ) {
                    return /\d{4}-\d{2}-\d{2}/.test(number);
                },
                message: "{ VALUE } is not a valid birthday"
            },
        ],
        required: [true, "Birthday required"]
    },
    password: {
        type: String,
        required: true,
        minlength: 8,
        // maxlength: 32,
        validate: {
            validator: function( value ) {
                return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,32}/.test( value );
            },
            message: "Password failed validation, you must have at least 1 number, uppercase and special character"
            }
        }, 
    confirm: {
        type: String,
        required: true,
        minlength: 8,
        // maxlength: 32,
        validate: {
            validator: function( value ) {
                return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,32}/.test( value );
            },
            message: "Password failed validation, you must have at least 1 number, uppercase and special character"
            }
        },     
    }, {timestamps: true}
));


// User.virtual( 'name.full' ).get( function () {
//     return this.name.first + " " + this.name.last;
//     // return `${ this.name.first } ${ this.name.last}`;
// });