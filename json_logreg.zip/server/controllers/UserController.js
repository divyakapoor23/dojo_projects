let session = require("express-session"),
    mongoose = require("mongoose"),
    // bcrypt = require("bcrypt");
    // bcrypt = require("bcrypt-as-promised");
    // bcrypt = require("bcrypt-nodejs-as-promised");    
    bcrypt = require("bcrypt-nodejs");

let User = mongoose.model("User");

class UserController{
    index(req, res) {
        res.json({message: "Login/Register Page"});
    }
    register(req, res) {
        User.find({email: req.body.email}, (err, user)=>{    
            if(err) {
                res.json({message: "Error registering", error: err});
            }
            else {
                if(user.length > 0) { 
                    res.json({message: "User with email "+req.body.email+" already exists.", error: err});
                }
                else {
                    let newUser = new User(req.body); 
                    newUser.password = bcrypt.hashSync(req.body.password);
                    let passcheck = bcrypt.compareSync(newUser.confirm, newUser.password);
                    if(passcheck == true) {
                        newUser.save(err=>{
                            if(err) {                          
                                res.json({message: "Error registering", error: err});
                            }
                            else {                         
                                res.json({message: "Successfully registered", data: newUser});
                            }
                        })
                    }
                    else {
                        res.json({error: "Password and Confirmation Password do not match"});
                    }
                }
            }
        })
    }
    login(req, res) {
        User.find({email: req.body.email}, (err, user)=> {
            if(err) {
                res.json({message: "Error", error: err});
            }
            else {
                if(user) {
                    bcrypt.compare(req.body.password, user[0].password, function(err, result) {
                        if(err) {
                            res.json({message: "Incorrect password", error: err});
                        }
                        else {
                            req.session.user_id = user[0]._id;
                            res.json({message: "Successfully logged in", data: user[0]});
                        }
                    })
                }
                else {
                    res.json({message: req.body.email + " does not exist.", error: err});
                }
            }
        })
    }
    dashboardAll(req, res) {
        User.find({}, (err, users)=> {
            if(err) {
                res.json({message: "Error retrieving all users", error: err});
            }
            else {
                res.json({message: "Success", data: users});
            }
        })
    }
}
module.exports = new UserController();