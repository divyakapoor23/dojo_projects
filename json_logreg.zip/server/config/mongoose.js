let path = require("path"),
    mongoose = require("mongoose"),
    fs = require("fs"),
    modelPath = path.join(__dirname,"./../models");

mongoose.connect("mongodb://localhost/json_logreg");
mongoose.Promise = global.Promise;

fs.readdirSync(modelPath).forEach(function(file){
    if(file.indexOf(".js") >= 0){
        require(modelPath+"/"+file);
    }
})
//just for connection to our database and creating instances of our models if they haven't already been created