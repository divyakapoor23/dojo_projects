let express = require("express"),
    bodyParser = require("body-parser"),
    session = require("express-session");
let app = express();

app.use(bodyParser.json());
app.use(express.json());
app.use(session({secret:"shhhhh"}));

require("./server/config/mongoose.js");
require("./server/config/routes.js")(app);

app.listen(6789,()=>{
	console.log("Server running on 6789");
});