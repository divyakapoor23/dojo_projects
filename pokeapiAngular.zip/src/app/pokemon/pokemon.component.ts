import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.css']
})
export class PokemonComponent implements OnInit {
  private pokemon:any;
  private abilities: any;
  private ableNpoke: any;

  constructor(private http: HttpService) { 

  }

  ngOnInit() {
    this.getPokemon();    
    this.abilityCheck();
  }

  getPokemon(){
    this.http.getPokemon((data)=>{
      this.pokemon = data;
      console.log(data);
      // for(let x of this.pokemon.abilities) {
      //   console.log(x.ability.url);
      // }
    })
    
  }

  abilityCheck() {
    console.log("yellow");
    console.log(this.pokemon.abilities);
    for(let x of this.pokemon.abilities) {
      let url = x.ability.url;
      console.log("hello");
      console.log(url);
      
      this.http.abilityCheck(url, (data)=> {
        console.log(data.pokemon.length); //data.pokemon is an array
        let pokearray = [];
        for(let poke of data.pokemon) {
          pokearray.push(poke.name);
        }
        this.ableNpoke[this.pokemon.abilities[x].ability.name] = [data.pokemon.length, pokearray];
      })   
    }
    console.log(this.ableNpoke);
  }

}
