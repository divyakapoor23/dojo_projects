import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {
  

  constructor(private _http: HttpClient) {
    
  }

  getPokemon(cb){
    this._http.get('https://pokeapi.co/api/v2/pokemon/470/')
    .subscribe(data=>cb(data));

  }
  abilityCheck(url, cb) {
    this._http.get(url)
    .subscribe(data=>cb(console.log(data)));
    
  }
}
