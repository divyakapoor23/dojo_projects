from flask import Flask, render_template, redirect, request, session
import random 
import datetime

app = Flask(__name__)
app.secret_key = 'SecretLikeANinja'

random.randrange(1, 101)


@app.route('/')
def ninja_home():
    if "golds" not in session:
        session['golds'] = 0
    if "log" not in session:
        session['log'] = []
    return render_template('home.html')

@app.route('/process_money', methods=['POST'])
def process_money(): 
    place = request.form['building']
    if place == "farm":
        golds = random.randrange(10, 21)
    elif place == "cave":
        golds = random.randrange(5, 11)
    elif place == "house":
        golds = random.randrange(2, 6)
    else:
        golds = random.randrange(-50, 51)   
    
    log_object = {}

    session['golds'] += golds
    if golds > 0:
        earned = "Earned"
        log_object['color'] = "green"
    else:
        earned = "Lost"
        log_object['color'] = "red"

    now = datetime.datetime.now()

    message = "{} {} golds from the {}! ({})".format(earned, golds, place, now.strftime("%Y/%m/%d %H:%M:%S"))
    log_object['message'] = message
    session['log'].insert(0, log_object)

    return redirect('/')

app.run(debug=True)



