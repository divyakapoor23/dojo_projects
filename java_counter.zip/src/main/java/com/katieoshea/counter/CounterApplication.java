package com.katieoshea.counter;

import javax.servlet.http.HttpSession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@SpringBootApplication
public class CounterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CounterApplication.class, args);
	}
	
	@Controller
	public class Counter {
		@RequestMapping ("/")
		public String index(HttpSession session) {
			if(session.getAttribute("count") == null) {
				session.setAttribute("count", 0);
			}
			int count = (int) session.getAttribute("count");
			count +=1;
			session.setAttribute("count", count);
			return "index";
		}
		
		@RequestMapping("/counter")
		public String visit(HttpSession session) {
			session.getAttribute("count");
			return "visit";
		}
		
		@RequestMapping ("/special")
		public String special(HttpSession session) {
			int count = (int) session.getAttribute("count");
			count +=2;
			session.setAttribute("count", count);
			return "special";
		}
		
		@RequestMapping ("/reset")
		public String reset(HttpSession session) {
			if(session.getAttribute("count") != null) {
				session.setAttribute("count", 0);
			}
			return "redirect:/counter";
		}
	}
}
