from flask import Flask, render_template, redirect

app = Flask(__name__)

@app.route('/')
def main():
    return "No ninjas here!"

@app.route('/ninjas')
def ninjas():
    return render_template('ninjas.html', color="tmnt")

@app.route('/ninjas/<color>')
def appear(color):
    if color == "blue":
        return render_template('ninjas.html', color="blue")
    elif color == "purple":
        return render_template('ninjas.html', color="purple")
    elif color == "orange":
        return render_template('ninjas.html', color="orange")
    elif color == "red":
        return render_template('ninjas.html', color="red")
    else:
        return render_template('ninjas.html', color="notapril")

app.run(debug=True)