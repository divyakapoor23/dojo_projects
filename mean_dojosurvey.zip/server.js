// npm init -y                  ==> package manager
// npm install express
// npm install ejs              ==> ejs templating
// npm install body-parser      ==> post data
// npm install express-session  ==> session

var express = require("express"),
    path = require("path"),
    bodyParser = require('body-parser'),
    session = require("express-session");

var app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
app.use(session({secret: 'cecinestpasunsecret'}));

app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    res.render("survey");
})
app.post('/submit', function (req, res){
    console.log("POST DATA \n\n", req.body)  
    req.session.count = 0;
    req.session.name = req.body.name;
    req.session.dojo = req.body.dojo;
    req.session.lang = req.body.lang;
    req.session.comment = req.body.comment;
    res.redirect('/results');
})
app.get('/results', function(req, res) {
    req.session.count++;
    res.render("results", {
        count: req.session.count, 
        name: req.session.name,
        dojo: req.session.dojo,
        lang: req.session.lang,
        comment: req.session.comment
    });
})

app.listen(6789, function() {
    console.log("listening on port 6789");
});