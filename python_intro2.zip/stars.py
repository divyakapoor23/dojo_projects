# PART I
def stars(count):
    for x in count:
        print ("*"*x)
stars([4, 6, 1, 3, 5, 7, 25])

# PART II
def draw_stars(starlist):
    for x in range(len(starlist)):
        if type(starlist[x]) == int:
            print ("*"*starlist[x])
        if type(starlist[x]) == str:
            letter = starlist[x][0]
            print(letter.lower()*len(starlist[x]))
draw_stars([4, "Tom", 1, "Michael", 5, 7, "Jimmy Smith"])
