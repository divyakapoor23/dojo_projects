def scores_grades():
    print "Scores and Grades"
    for x in range(10):
        import random
        grade = random.randint(60, 100)
        letter = ""
        # print grade
        if grade >= 60 and grade < 70:
            letter = "D"
        if grade >= 70 and grade < 80:
            letter = "C"
        if grade >= 80 and grade < 90:
            letter = "B"
        if grade >= 90 and grade < 101:
            letter = "A"
        print "Score: {}; Your grade is {}".format(grade, letter)
    print "End of the program. Bye!"
scores_grades()