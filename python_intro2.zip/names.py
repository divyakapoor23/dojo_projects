# PART I
def names():
    students = [
        {
            'first_name': 'Michael', 
            'last_name': 'Jordan'
        },
        {
            'first_name': 'John', 
            'last_name': 'Rosales'
        },
        {
            'first_name': 'Mark', 
            'last_name': 'Guillen'
        },
        {
            'first_name': 'KB', 
            'last_name': 'Tonel'
        }
    ]

    for person in students:
        full_name = "" 
        for key in person:
            full_name += person[key] + " "
        print full_name
names()

# PART II
def usernames():
    users = {
        'Students': [
            {'first_name':  'Michael', 'last_name' : 'Jordan'},
            {'first_name' : 'John', 'last_name' : 'Rosales'},
            {'first_name' : 'Mark', 'last_name' : 'Guillen'},
            {'first_name' : 'KB', 'last_name' : 'Tonel'}
        ],
        'Instructors': [
            {'first_name' : 'Michael', 'last_name' : 'Choi'},
            {'first_name' : 'Martin', 'last_name' : 'Puryear'}
        ]
    }
    for usertype in users:
        print usertype
        index = 0
        for person in users[usertype]:
            full_name = ""
            index += 1
            for key in person:
                full_name += person[key] + " "
            print "{} - {}- {}".format(index, full_name, len(full_name)-2)      
usernames()