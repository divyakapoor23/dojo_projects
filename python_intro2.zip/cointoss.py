def cointoss():
    print "Starting the program..."
    odds = 0
    coin = ""
    heads = 0
    tails = 0
    for x in range(1,5001): #change to 5000 at end
        import random
        odds = random.random()
        odds_rounded = round(odds)
        if odds_rounded == 0:
            coin = "head"
            heads +=1
        else:
            coin = "tail"
            tails += 1
        print "Attempt #{}: Throwing a coin... It's a {}! ... Got {} head(s) so far and {} tail(s) so far.".format(x,coin,heads,tails)
    print "Ending the program, thank you!"
cointoss()