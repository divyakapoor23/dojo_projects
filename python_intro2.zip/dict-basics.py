def dict_basics(): 
    mydict = {
        "name": "Anna",
        "age": 101,
        "country of birth": "The United States",
        "favorite language": "Python"
    }
    for key in mydict:
        # print mydict[key]
        print "My {} is {}".format(key, mydict[key])
dict_basics()