# With built in functions
def dict2tuple():
    my_dict = {
    "Speros": "(555) 555-5555",
    "Michael": "(999) 999-9999",
    "Jay": "(777) 777-7777"
    }
    my_tuple = my_dict.items()
    print my_tuple
dict2tuple()

# Without built-in functions
def dict2tuple2():
    my_dict = {
    "Speros": "(555) 555-5555",
    "Michael": "(999) 999-9999",
    "Jay": "(777) 777-7777"
    }
    new_list = []
    for x in my_dict:
        contact = x, my_dict[x]
        tuple(contact)
        new_list.append(contact)
    print new_list
dict2tuple2()