# With built in functions
def make_dict(list1, list2):
    zip_list = zip(list1, list2)
    new_dict = dict(zip_list)
    print new_dict
make_dict(["Anna", "Eli", "Pariece", "Brendan", "Amy", "Shane", "Oscar"], ["horse", "cat", "spider", "giraffe", "ticks", "dolphins", "llamas"])

# Without built-in functions
def make_dict2(list1, list2):
    newdict = {}
    for x in range(len(list1)):
        newdict[list1[x]] = list2[x]
    print newdict
make_dict2(["Anna", "Eli", "Pariece", "Brendan", "Amy", "Shane", "Oscar"], ["horse", "cat", "spider", "giraffe", "ticks", "dolphins", "llamas"])

# Hacker challenge
def hacker_dict(list1, list2):
    if len(list1) == len(list2):
        newdict = {}
        for x in range(len(list1)):
            newdict[list1[x]] = list2[x]
        print newdict
    else: 
        if len(list1) > len(list2):
            newdict = {}
            for x in range(len(list1)-1):
                newdict[list1[x]] = list2[x]
                newdict[list1[-1]] = "Unknown entry"
            print newdict
        else: #len(list1) < len(list2):
            newdict = {}
            for x in range(len(list2)-1):
                newdict[list2[x]] = list1[x]
                newdict[list2[-1]] = "Unknown entry"
            print newdict
hacker_dict(["Anna", "Eli", "Pariece", "Brendan", "Amy", "Shane", "Oscar"], ["horse", "cat", "spider", "giraffe", "ticks", "dolphins", "llamas"])
hacker_dict(["Anna", "Eli", "Pariece", "Brendan", "Amy", "Shane", "Oscar"], ["horse", "cat", "spider", "giraffe", "ticks", "dolphins", "llamas", "platypodes"])
hacker_dict(["Anna", "Eli", "Pariece", "Brendan", "Amy", "Shane", "Oscar", "Katie"], ["horse", "cat", "spider", "giraffe", "ticks", "dolphins", "llamas"])
