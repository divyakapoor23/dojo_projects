#Odd/Even
for num in range(1,2000):
    if num%2 == 0:
        print "Number is " + str(num) + ". This is an even number."
    else:
        print "Number is " + str(num) + ". This is an odd number."

#Multiply 
def multiply(a, b):
    new = []
    for x in a:
                new.append(x*b)
    print new
multiply([2,4,10,16], 5)

#hacker Challenge
def hacker(arr, b):
    new = []
    for i in arr:
        new.append(i*b)
    print new
    layered_multiples = []
    for x in new:
        layered_multiples.append([1,]*x)
    print layered_multiples
hacker([2,4,5],3)
