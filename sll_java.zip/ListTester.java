class ListTester {
    public static void main(String[] args){
        SinglyLinkedList list1 = new SinglyLinkedList();

        list1.add(5);
        list1.add(6);
        list1.add(7);
        list1.add(8);
        list1.add(9);
        list1.remove();
        list1.add(99);
        list1.add(1);
        list1.add(2);
        list1.printValues();
        System.out.println(list1.find(99));
        list1.removeAt(4);
        list1.printValues();
        list1.add(3);
        list1.add(4);
        list1.add(47);
        list1.add(48);
        System.out.println("*****");
        list1.printValues();
        System.out.println("*****");
        list1.removeAt(22);
        list1.removeAt(9);
        list1.printValues();
    }
}