class Node {
    private int value;
    protected Node next;
    
    public Node(int value) {
        this.value = value;
        this.next = null;
    }
    public int getNodeVal() {
        return value;
    }
    public void setNext(Node nextNode) {
        next = nextNode;
    }
}