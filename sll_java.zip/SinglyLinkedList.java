class SinglyLinkedList {
    Node head;
    Node runner;

    public SinglyLinkedList(){
        head = null;
    }
    public void add(int val) {
        Node newNode = new Node(val);

        if(this.head == null) {
            this.head = newNode; 
        }
        else {
            runner = this.head;
            while(runner.next != null) {
                runner = runner.next;
            }
            runner.setNext(newNode);
        }
    }
    public void remove() {
        runner = this.head;
        while(runner.next.next != null) {
            runner = runner.next;
        }
        runner.setNext(null);
    }
    public void printValues() {
        runner = this.head;
        while(runner != null) {
            System.out.println(runner.getNodeVal());
            runner = runner.next;
        }
    }
    public Node find(int num) {
        runner = this.head;
        while(runner != null) {
            if(runner.getNodeVal() == num) {
                return runner;
            }
            runner = runner.next;
        }
        return null;
    }
    public void removeAt(int n) {
        runner = this.head;
        int count = 0;
        while(runner.next != null){
            count += 1;
            runner=runner.next;
        }
        if(n > count) {
            System.out.println("There aren't that many nodes in this list");
        }
        else {
            runner = this.head;
            int index = 0;
            while(index < n-1) {
                runner = runner.next;
                index++;
            }
            System.out.println("Removing "+runner.next+" (value of "+runner.next.getNodeVal()+ ") at index "+n+ " in the list.");
            if(runner.next == null) {
                runner.setNext(null);
            }
            else {
                Node skip = runner.next.next;
                runner.setNext(skip);
            }
        }
    }
}