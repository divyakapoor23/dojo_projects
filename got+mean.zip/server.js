// var http = require('http');
// var fs   = require('fs');


// var server = http.createServer(function(request,response){
    
//     if(request.url === '/') {     
//         fs.readFile('got.html', 'utf8', function (errors, contents){
//             response.writeHead(200, {'Content-Type': 'text/html'});
//             response.write(contents);
//             response.end();
//         });
//     }    
//     else if(request.url === '/style') { 
//         fs.readFile('got.css', 'utf8', function (errors, contents){
//             response.writeHead(200, {'Content-Type': 'text/css'});
//             response.write(contents); 
//             response.end();
//         });   
//     }
//     else if(request.url === '/stark') { 
//         console.log("OUR SERVER IS RUNNING");
//         fs.readFile('stark.jpg', 'utf8', function (errors, contents){
//             response.writeHead(200, {'Content-Type': 'image/jpeg'});
//             response.write(contents); 
//             response.end();
//         });   
//     }
//     else{
//         response.writeHead(404);
//         response.end('File not found!!!');
//     }
// });

// server.listen(5678,  () =>{
//     console.log("OUR SERVER IS RUNNING ON PORT 5678");
// });