import java.util.ArrayList;

import org.omg.CORBA.TRANSACTION_UNAVAILABLE;

class Portfolio{
    public static ArrayList<Project> projects = new ArrayList<Project>();

    public static double getPortfolioCost() {
        double total = 0;
        for(Project x: projects){
            double costx = x.getCost();
            total += costx;
        }
        return total;
    }

    public static void showPortfolio() {
        double totalCost = getPortfolioCost();
        Double.toString(totalCost);

        for(Project x: projects){
            System.out.println(x.getName() + " ($" + x.getCost() + "): " + x.getDesc());
        }   
        
        System.out.println("Portfolio Total: $" + String.format("%.2f", totalCost));
     
    }

}