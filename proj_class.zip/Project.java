import java.util.ArrayList;

class Project{
    private String name;
    private String description;
    private double initialCost;

    public static ArrayList<Project> projects = new ArrayList<Project>();

    public Project() {
        Portfolio.projects.add(this);

    }
    public Project(String name){
        this.name = name;
 
        Portfolio.projects.add(this);
    }
    public Project(String name, String description, double initialCost) {
        this.name = name;
        this.description = description;
        this.initialCost = initialCost;
 
        Portfolio.projects.add(this);
    }

    public void setName(String projName) {
        name = projName;
    }
    public String getName() {
        return name;
    }
    public void setDesc(String projDesc) {
        description = projDesc;
    }
    public String getDesc() {
        return description;
    }  
    public void setCost(double amount) {
        initialCost = amount;
    }
    public double getCost() {
        return initialCost;
    }  
}