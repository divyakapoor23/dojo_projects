
public class ProjectTest {
    public static void main(String[] args) {
        Project elevatorPitch = new Project();
        elevatorPitch.setName("Elevator Pitch");
        elevatorPitch.setDesc("Pitch for selling elevators");
        elevatorPitch.setCost(15000.00);
        String elevName = elevatorPitch.getName();
        String elevDesc = elevatorPitch.getDesc();
        double elevCost = elevatorPitch.getCost();

        Project rugbyPitch = new Project("Rigby Fields", "Build group of Rugby pitches for community", 14999.99);
        Project acaPitch = new Project("Pitch Perfect", "College girls in a acapella group", 999.99);

        Portfolio.showPortfolio();
    }
}