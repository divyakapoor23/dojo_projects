class car(object):
    def __init__(self, price, speed, fuel, mileage, tax):
        self.price = price
        self.speed = speed  
        self.fuel = fuel
        self.mileage = mileage
        self.tax = tax
    def displayAll(self):
        print "Price: ${}\n Speed: {}mph\n Fuel: {}\n Mileage: {}mpg\n Tax: {}".format(self.price, self.speed, self.fuel, self.mileage, self.tax)
        return self
    def taxation(self):
        if self.price>10000:
            self.tax = 0.15
        else:
            self.tax = 0.12
        return self

car1 = car(200,25,"Full",34.6,0)
car2 = car(15000,95,"Empty",16.8,0)
car3 = car(22050,30,"4/8",12.0,0)
car4 = car(2005,55,"3/8",25.7,0)
car5 = car(10500,15,"Not Full",18.9,0)
car6 = car(9999,65,"Kind of Full",28.0,0)

car1.taxation().displayAll()
car2.taxation().displayAll()
car3.taxation().displayAll()
car4.taxation().displayAll()
car5.taxation().displayAll()
car6.taxation().displayAll()