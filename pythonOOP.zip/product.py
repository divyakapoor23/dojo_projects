class product(object):
    def __init__(self, price, item_name, weight, brand):
        self.price = price
        self.item_name = item_name  
        self.weight = weight
        self.brand = brand
        self.status = "for sale"
        self.return_item = False
        self.boxed = False
    def displayInfo(self):
        print "Brand: {}\nItem: {}\nWeight: {}oz.\nStatus: {}\nPrice: ${}\n--".format(self.brand, self.item_name, self.weight, self.status, self.price)
        return self
    def sell(self):
        self.status = "sold"
        return self
    def add_tax(self):
        self.price = float(self.price)*1.08
        return self
    def return_damaged(self): 
        self.return_item == True
        self.boxed == False
        self.status = "defective"
        self.price = 0
        return self
    def return_used(self):
        self.return_item == True
        self.boxed == True
        self.status = "used"
        self.price = float(self.price)*0.80
        return self


product1 = product(25, "Doll", 18, "Barbie")
product2 = product(6.75, "Hot Wheels", 1, "Mattel")
product3 = product(216, "Video Game", 35, "EA")
product4 = product(32, "Board Game", "Monopoly", 82)

product1.sell().add_tax().displayInfo()
product2.return_used().displayInfo()
product3.return_damaged().displayInfo()
product4.add_tax().displayInfo()
