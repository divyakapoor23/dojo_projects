class bike(object):
    def __init__(self, price, max_speed, miles):
        self.price = price
        self.max_speed = max_speed  
        self.miles = miles
    def displayInfo(self):
        print "This bike cost ${}, it's maximum speed is {} mph, and total miles is {} miles.".format(self.price, self.max_speed, self.miles)
        return self
    def ride(self):
        self.miles += 10
        print "Riding..."
        return self
    def reverse(self):
        self.miles -= 5
        if self.miles<0:
            self.miles = 0

        print "Reversing..."
        return self

bike1 = bike(200,25,0)
bike2 = bike(150,15,0)
bike3 = bike(225,30,0)

bike1.ride().ride().ride().reverse().displayInfo()
bike2.ride().ride().reverse().reverse().displayInfo()
bike3.reverse().reverse().reverse().displayInfo()