package com.katieoshea.dojosurvey;

import javax.servlet.http.HttpSession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@SpringBootApplication
public class DojosurveyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojosurveyApplication.class, args);
	}
	
	@Controller
	public class DojoSurvey {
		@RequestMapping("/")
		public String index() {
			return "index";
		}
		
		@RequestMapping("/results")
		public String results() {
			return "results";
		}
	}
		
	@Controller
	public class Submitter {
		@RequestMapping(path="/submit", method=RequestMethod.POST)
		public String survey(HttpSession session, @RequestParam(value="name") String name, @RequestParam(value="dojo") String dojo, @RequestParam(value="lang") String lang, @RequestParam(value="comment") String comment) {
	    	session.setAttribute("name", name);
	    	session.setAttribute("dojo", dojo);
	    	session.setAttribute("lang", lang);
			session.setAttribute("comment", comment);
			
			if(session.getAttribute("count") == null) {
				session.setAttribute("count", 0);
			}
			int count = (int) session.getAttribute("count");
			count +=1;
			session.setAttribute("count", count);
			
	    	return "redirect:/results";
		}
	}
}
