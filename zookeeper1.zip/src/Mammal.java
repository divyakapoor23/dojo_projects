
public class Mammal {
	private int energyLevel;
	public Mammal () {
		this.energyLevel = 100;
	}
	public void setEnergyLevel(int newLev) {
		energyLevel = newLev;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int displayEnergy() {
		int level = this.getEnergyLevel();
		System.out.println(level);
		return level;
	}
}
