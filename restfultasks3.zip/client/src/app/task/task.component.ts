import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  private task: any;
  private tasks: any;
  constructor(private taskServ: TaskService) {
    
  }
  ngOnInit() {
    this.all();
    this.task = {
      title: "",
      description: "",
      completed: false
    };
  }

  create() { 
    this.taskServ.create(this.task, (data)=>{ 
      console.log("Created this task", data);
    });
  }
  all() {
    this.taskServ.getTasks(data=>{
      this.tasks = data;
      console.log("Got our tasks!", data);
    });
  }
  show() {
    this.taskServ.show(data=>{
      this.task = data;
      console.log("Show this task", data);
    });
  }

}
