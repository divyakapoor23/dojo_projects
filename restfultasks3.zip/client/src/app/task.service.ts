import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class TaskService {

  constructor(private http: HttpClient) {
    
  }

  getTasks(cb) {
    this.http.get("/tasks")
    .subscribe(data=>cb(data));
  }
  show(cb) {
    this.http.get("/tasks/:id")
    .subscribe(data=>cb(data));
  }
  create(task, cb) { 
    this.http.post("/tasks", task) 
    .subscribe(data=>cb(data)); 
  } 
}
