let UserController = require("../controllers/TaskController.js");

module.exports = function(app){
    app.get("/tasks", UserController.all);
    app.post("/tasks", UserController.create);
    app.get("/tasks/:id", UserController.show);
    app.put("/tasks/:id", UserController.edit);
    app.delete("/tasks/:id", UserController.delete);    
}