package com.katieoshea.relationships.repositories;

import com.katieoshea.relationships.models.License;
import com.katieoshea.relationships.models.Person;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

public interface LicenseRepository extends CrudRepository<License, Long>{
   
}
