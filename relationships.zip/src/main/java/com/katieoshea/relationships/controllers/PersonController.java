package com.katieoshea.relationships.controllers;

import com.katieoshea.relationships.models.Person;
import com.katieoshea.relationships.models.License;
import com.katieoshea.relationships.services.LicenseService;
import com.katieoshea.relationships.services.PersonService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PersonController {
	private PersonService pServ;
	private LicenseService lServ;
	public PersonController(PersonService pServ){
		this.pServ=pServ;
		this.lServ = lServ;
	}
	@RequestMapping("/persons/new")
	public String create(Model model) {
		model.addAttribute("newPerson", new Person());
        return "newP";
    }
	@PostMapping("/persons/new")
	public String create(@Validated @ModelAttribute("newPerson") Person person, BindingResult result) {
		if(result.hasErrors()) {
			return "newP"; 
		}
		pServ.create(person);
		return "redirect:/persons/new";
	}
	@RequestMapping("/persons/{id}")
	public String show(Model model, @PathVariable("id") Long id) {
		Person them = pServ.find(id);
		model.addAttribute("them", them);
        return "profile";
    }
	
}
