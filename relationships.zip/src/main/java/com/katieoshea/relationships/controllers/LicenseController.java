package com.katieoshea.relationships.controllers;

import com.katieoshea.relationships.models.License;
import com.katieoshea.relationships.models.Person;
import com.katieoshea.relationships.services.LicenseService;
import com.katieoshea.relationships.services.PersonService;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LicenseController {
    private LicenseService lServ;
    private PersonService pServ;
	public LicenseController(LicenseService lServ, PersonService pServ){
        this.lServ=lServ;
        this.pServ=pServ;
	}
	
	private static int LiNo = 0;
	private ArrayList<String> states = new ArrayList<String>(Arrays.asList("AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY"));

    @RequestMapping("/licenses/new")
	public String create(Model model) {
        model.addAttribute("states", states);
        
        ArrayList<Person> list = pServ.all();
        ArrayList<Person> nolicense = new ArrayList<Person>();
        for(Person person: list) {
        	if(person.getLicense() == null) {
        		nolicense.add(person);
        	}
        }
        model.addAttribute("people", nolicense);
        
		model.addAttribute("newLicense", new License());
        return "newL";
    }
	@PostMapping("/licenses/new")
	public String create(@Validated @ModelAttribute("newLicense") License license, BindingResult result, Model model) {
		if(result.hasErrors()) {
//			System.out.println(result.getAllErrors());
	        model.addAttribute("states", states);
	        
			model.addAttribute("newLicense", new License());
			return "newL"; 
		}
		else {
			LiNo++;
			String LiNum = Integer.toString(LiNo);
			String number = "";
			if(LiNo < 10) {
				number = "00000" + LiNum;
			}
			else if (LiNo < 100){
		        number = "0000" + LiNum;
		    }
			else if (LiNo < 1000) {
		        number = "000" + LiNum;
		    }
			else if (LiNo < 10000) {
		        number = "00" + LiNum;
		    }
			else if (LiNo < 100000) {
		        number = "0" + LiNum;
		    }
			else {
				number = LiNum;
			}
			
			license.setNumber(number);
			lServ.create(license);
	
			return "redirect:/licenses/new";
		}
	}
}
