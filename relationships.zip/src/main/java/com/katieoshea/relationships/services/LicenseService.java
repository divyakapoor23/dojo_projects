package com.katieoshea.relationships.services;

import com.katieoshea.relationships.models.License;
import com.katieoshea.relationships.models.Person;
import com.katieoshea.relationships.repositories.LicenseRepository;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class LicenseService {
    private LicenseRepository licenseRepo;
    public LicenseService(LicenseRepository licenseRepo) {
        this.licenseRepo = licenseRepo;
    }

    public ArrayList<License> all() {
		return (ArrayList<License>) licenseRepo.findAll();
	}

	public License findLicense(Long id) {
		return (License) licenseRepo.findOne(id);
    }
    
    public void create(License license) {
		licenseRepo.save(license);
	}
}
