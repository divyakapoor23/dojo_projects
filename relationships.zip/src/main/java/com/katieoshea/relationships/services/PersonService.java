package com.katieoshea.relationships.services;

import com.katieoshea.relationships.models.Person;
import com.katieoshea.relationships.repositories.PersonRepository;

import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service
public class PersonService {
    private PersonRepository personRepo;
    public PersonService(PersonRepository personRepo) {
        this.personRepo = personRepo;
    }

    public ArrayList<Person> all() {
		return (ArrayList<Person>) personRepo.findAll();
	}

	public Person find(Long id) {
		return (Person) personRepo.findOne(id);
    }
    
    public void create(Person person) {
		personRepo.save(person);
	}
}
