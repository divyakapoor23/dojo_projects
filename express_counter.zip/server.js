// npm init -y                  ==> package manager
// npm install express
// npm install ejs              ==> ejs templating
// npm install body-parser      ==> post data
// npm install express-session  ==> session

var express = require("express"),
    path = require("path"),
    bodyParser = require('body-parser'),
    session = require("express-session");

var app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
app.use(session({secret: 'cecinestpasunsecret'}));

app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    if(req.session.count == null) {
        req.session.count = 0;
    }
    req.session.count++;
    res.render("index", {count: req.session.count});
})
app.get('/two', function(req, res) {
    req.session.count++;
    res.redirect('/');
})
app.get('/reset', function(req, res) {
    req.session.count = 0;
    res.redirect('/');
})

app.listen(6789, function() {
    console.log("listening on port 6789");
});