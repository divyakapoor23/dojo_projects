from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect

def index(request):
    return render(request, 'survey_form/index.html')

def process(request):
    if 'count' not in request.session:
        request.session['count'] = 1
    else:
        request.session['count'] += 1
    if request.method == "POST":
        request.session['name'] = request.POST['name']
        request.session['dojo'] = request.POST['dojo']
        request.session['lang'] = request.POST['lang']
        request.session['comment'] = request.POST['comment']
    
    return redirect('/result')

def result(request):
    return render(request, 'survey_form/surv_res.html')
  
