
public class Samurai extends Human{
	public static int count = 0;
	public Samurai() {
		this.setHealth(200);
		count += 1;
	}
	public void deathBlow(Human otherHuman) {
		otherHuman.setHealth(0);
		this.setHealth(this.getHealth()/2);
	}
	public void meditate() {
		int currentHealth = this.getHealth();
		this.setHealth(currentHealth*3/2);
	}
	public void howMany() {
		System.out.println("There are "+count+" samurais.");
	}
}
