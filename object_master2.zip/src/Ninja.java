
public class Ninja extends Human{
	public Ninja() {
		this.setStealth(10);
	}
	public void steal(Human otherHuman) {
		int otherHealth = otherHuman.getHealth();
		otherHuman.setHealth(otherHealth-this.getStealth());
		this.setHealth(this.getHealth() + this.getStealth());
	}
	public void runAway() {
		this.setHealth(this.getHealth() - 10);
	}
}
