
public class Human {
	private int strength = 3;
	private int intelligence = 3;
	private int stealth = 3;
	private int health = 100;
	
	public Human() {
		
	}
	public void setStrength(int strong) {
		this.strength = strong;
	}
	public int getStrength() {
		return strength;
	}
	
	public void setIntelligence(int smart) {
		this.intelligence = smart;
	}
	public int getIntelligence() {
		return intelligence;
	}	
	
	public void setStealth(int sneak) {
		this.stealth = sneak;
	}
	public int getStealth() {
		return stealth;
	}	
	
	public void setHealth(int fitness) {
		this.health = fitness;
	}
	public int getHealth() {
		return health;
	}
	public int displayHealth() {
		int level = this.getHealth();
		System.out.println(this+"'s health is "+level);
		return level;
	}
	
	public void attack(Human otherHuman) {
		int otherHealth = otherHuman.getHealth();
		otherHuman.setHealth(otherHealth-20);
	}
}
