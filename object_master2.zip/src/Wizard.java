
public class Wizard extends Human{
	public Wizard() {
		this.setHealth(50);
		this.setIntelligence(8);
	}
	public void heal(Human otherHuman) {
		int otherHealth = otherHuman.getHealth();
		otherHuman.setHealth(otherHealth+this.getIntelligence());
	}
	public void fireball(Human otherHuman) {
		int otherHealth = otherHuman.getHealth();
		otherHuman.setHealth(otherHealth-(this.getIntelligence()*3));
	}
}
