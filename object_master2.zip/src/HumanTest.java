
public class HumanTest {
	public static void main(String[] args) {
		Human katie = new Human();
		Human caroline = new Human();
		
		katie.attack(caroline);
		caroline.displayHealth();
		
		Wizard brian = new Wizard();
		Ninja brian2 = new Ninja();
		Wizard tim = new Wizard();
		Samurai sal = new Samurai();
		Ninja key = new Ninja();
		Samurai sean = new Samurai();
		sean.howMany();
		sal.howMany();
	}
}
