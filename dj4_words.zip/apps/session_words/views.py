from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime


def index(request):
    return redirect('/session_words')

def addword(request):
    if request.method == 'POST':
        if 'size' not in request.POST:
            size = "normal"
        else:
            size = "big"
        added = {
            "word": request.POST['word'],
            "color": request.POST['color'],
            "size": size,
            "posted": strftime("%I:%M:%S%p, %B %d, %Y", gmtime())
        }
        if 'words' not in request.session:
            request.session['words'] = [] 
            request.session['words'].append(added)
        else:
            request.session['words'].append(added)
            request.session.modified = True
        return redirect('/')

def reset(request):
    request.session.clear
    return redirect('/')

def show(request):
    return render(request, 'session_words/index.html')