from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^add_word$', views.addword),
    url(r'^session_words/clear', views.reset),
    url(r'^session_words', views.show)
]
