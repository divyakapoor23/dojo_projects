
public class HumanTest {
	public static void main(String[] args) {
		Human katie = new Human();
		Human caroline = new Human();
		
		katie.attack(caroline);
		caroline.displayHealth();
	}
}
