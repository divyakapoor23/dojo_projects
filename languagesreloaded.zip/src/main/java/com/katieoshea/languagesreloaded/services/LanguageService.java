package com.katieoshea.languagesreloaded.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.katieoshea.languagesreloaded.models.Language;
import com.katieoshea.languagesreloaded.repositories.LanguageRepository;

@Service
public class LanguageService {
//	@Autowired
    private LanguageRepository lR;
    public LanguageService(LanguageRepository lR) {
    	this.lR = lR;
    }
    //Crud methods act on services here
    //CRUD - CREATE READ UPDATE DESTROY

    public void create(Language language) {
        //talk to repository here based on what we are creating
        lR.save(language); //speaks to mySQL
    }
    public List<Language> allLangs() {
//    	System.out.println(lR);
    	return (List<Language>)lR.findAll();
    }
    public Optional<Language> findById(Long id) {
        return (Optional<Language>)lR.findById(id); //speaks to MySQL
    }
    public void update(Language language){
        lR.save(language);
    }
    public void destroy(Long id){
        lR.deleteById(id);
    }
}
