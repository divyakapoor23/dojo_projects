package com.katieoshea.languagesreloaded.repositories;


import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.katieoshea.languagesreloaded.models.Language;

@Repository 
public interface LanguageRepository extends CrudRepository<Language,Long>{


}
