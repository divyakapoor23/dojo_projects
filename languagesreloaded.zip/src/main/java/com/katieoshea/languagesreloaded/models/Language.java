package com.katieoshea.languagesreloaded.models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
// @Table(name="languages")
public class Language {
    @Id //set id property for primary key 
    @GeneratedValue //autoincrement
    private Long id;

    @Size(min=1,max=64,message="You must enter a Language")
    private String name;

    @Size(min=1,max=64,message="You must enter a Creator")
    private String creator;

    @NotNull // so you have to enter something
    private double version;

    @DateTimeFormat(pattern="MM-dd-yyyy HH:mm:ss")
    private Date createdAt;
    
    @DateTimeFormat(pattern="MM-dd-yyyy HH:mm:ss")
    private Date updatedAt;

// Setters and getters go here

    public void setName(String name) {
        this.name=name;
    }
    public String getName() {
        return name;
    }
    public void setCreator(String creator) {
        this.creator=creator;
    }
    public String getCreator() {
        return creator;
    }    
    public void setVersion(double version) {
        this.version=version;
    }
    public double getVersion() {
        return version;
    }
    @PrePersist
    protected void onCreate(){
        this.createdAt = new Date();
    }
    @PreUpdate
    protected void onUpdate(){
        this.updatedAt = new Date();
    }
// Constructors

    public Language() {
    	this.id = id;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    public Language(String name, String creator, Double version) {
    	this.id = id;
        this.createdAt = new Date();
        this.updatedAt = new Date();
        this.name = name;
        this.creator = creator;
        this.version = version;
    }
}
