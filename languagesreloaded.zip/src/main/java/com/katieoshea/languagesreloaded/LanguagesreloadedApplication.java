package com.katieoshea.languagesreloaded;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanguagesreloadedApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanguagesreloadedApplication.class, args);
	}
}
