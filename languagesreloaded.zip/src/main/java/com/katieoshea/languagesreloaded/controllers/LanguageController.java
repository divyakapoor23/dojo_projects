package com.katieoshea.languagesreloaded.controllers;

import java.util.Optional;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.katieoshea.languagesreloaded.models.Language;
import com.katieoshea.languagesreloaded.repositories.LanguageRepository;
import com.katieoshea.languagesreloaded.services.LanguageService;

@Controller
@RequestMapping("/languages")
public class LanguageController {
	@Autowired
	private LanguageRepository lR;
	public LanguageController(LanguageRepository lR) {
		this.lR = lR;
	}
	
	@RequestMapping("")
	public String languages(Model model) {
		model.addAttribute("langs", lR.findAll()); //calling to show all the lanauges on the page with keyword languages
		model.addAttribute("language", new Language()); //create a blank object for language
		return "AllLangs"; //languages.jsp
	}
	@PostMapping("")
	public String create(@Valid @ModelAttribute("language") Language language, BindingResult result, Model model) { // look for created blank object, no longer blank, validate it, create the language 
		if(result.hasErrors()) {
			model.addAttribute("langs", lR.findAll());
			return "AllLangs"; 
		}
		lR.save(language);	
		return "redirect:/languages";
	}
	
	@RequestMapping("/{id}")
	public String findLanguage( @PathVariable("id") Long id, Model model) {
		model.addAttribute("lang", lR.findById(id));
		model.addAttribute("langs", lR.findAll());
		return "showLang";
	}
	
	@RequestMapping("/edit/{id}")
	public String editLang( @PathVariable("id") Long id, Model model) {
		model.addAttribute("lang", lR.findById(id));
		model.addAttribute("langs", lR.findAll());
		return "updateLang";
	}
	@PostMapping("/edit/{id}")
	public String updateLang( @PathVariable("id") Long id, Model model) {
		Optional<Language> lang = lR.findById(id);
		lR.update(lang);
		return "redirect:/languages/{id}";
	}	
	
	@PostMapping("/delete/{id}")
	public String deleteLanguage( @PathVariable("id") Long id) {
		lR.deleteById(id);
		return "redirect:/languages";
	}
}
