var express = require('express'),
    path = require('path'),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose');
var app = express(); 

app.use(bodyParser.urlencoded({ extended : true}));
app.use(express.static(path.join(__dirname, "./static")));

app.set("views", path.join(__dirname, "./views"));
app.set("view engine", "ejs");

mongoose.connect("mongodb://localhost/mongoose");
mongoose.Promise = global.Promise;

mongoose.model("Animal", new mongoose.Schema({
    name: String,
    about: String
}));
var Animal = mongoose.model("Animal");

app.get("/", function(req, res) {
    Animal.find({}, (err, animals)=> {
        if(err) {
            console.log(err);
            console.log("1");            
        }
        else {
            res.render("dashboard", {animals: animals});
        }
    })
})
app.get("/mongooses/new", function(req, res) {                           
    res.render("new");
})
app.post("/mongooses", function(req, res) {
    let newAnimal = new Animal(req.body);
    newAnimal.save(function(err) {
        if(err) {
            console.log("something went wrong");
            res.render("index", {errors: err});
        }
        else {
            res.redirect("/");
        }
    }) 
})
app.get("/mongooses/:id", function(req, res) {
    Animal.find({_id: req.params.id}, (err, animal)=> {
        if(err) {
            console.log(err);
            console.log("2");            
            res.redirect("/");
        }
        else {
            res.render("show", {animal: animal[0]});
        }
    })
})
app.get("/mongooses/edit/:id", function(req, res) {
    Animal.find({_id: req.params.id}, (err, animal)=> {
        if(err) {
            console.log(err);
            console.log("3");            
            res.redirect("/");
        }
        else {
            res.render("edit", {animal: animal[0]});
        }
    })
})
app.post("/mongooses/:id", function(req, res) {
    Animal.find({_id: req.params.id}, (err, animal)=> {
        if(err) {
            console.log(err);
            console.log("4");            
            res.redirect("/mongooses/edit/animal._id");
        }
        else {
            let updated = animal[0];
            updated.name = req.body.name;
            updated.about = req.body.about;            
            updated.save(function(err) {
                if(err) {
                    console.log("5");
                    res.render("edit", {errors: err});
                }
                else {
                    res.redirect("/");
                }
            });
        }
    })
})
app.post("/mongooses/destroy/:id", function(req, res) {
    Animal.find({_id: req.params.id}, (err, animal)=> {
        if(err) {
            console.log(err);
            console.log("6");            
            res.redirect("/");
        }
        else {          
            let deleting = animal[0];
            deleting.remove();   
            res.redirect("/");
        }
    })
})


app.listen(6789, function() {
    console.log("listening on port 6789");
})