var express = require("express"),
    bodyParser = require("body-parser"),
    path = require("path"),
    mongoose = require("mongoose");
var app = express();

app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname, "./static")));
app.set("views", path.join(__dirname, "./views"));
app.set("view engine", "ejs");

mongoose.connect("mongodb://localhost/msgboard");
mongoose.Promise = global.Promise;

var Schema = mongoose.Schema;
mongoose.model("Message", new mongoose.Schema({
        name: { type: String, required: true, minlength: 4, maxlength: 255 }, 
        message: { type: String, required: true, minlength: 6, maxlength: 511 }, 
        comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
    }, { timestamps: true }
));
mongoose.model("Comment", new mongoose.Schema({
    name: { type: String, required: true, minlength: 4, maxlength: 255  }, 
    comment: { type: String, required: true, minlength: 6, maxlength: 511 }, 
    _message: [{type: Schema.Types.ObjectId, ref: 'Message'}]
}, { timestamps: true }
));
var Message = mongoose.model("Message");
var Comment = mongoose.model("Comment");

app.get("/", function(req, res) {
    Message.find({}, (err, messages)=> {
        if(err) {
            console.log("error grabbing all messages");            
        }
        else {
            Comment.find({}, (err, comments)=> {
                if(err) {
                    console.log("error grabbing all comments");            
                }
                else {
                    res.render("index", {messages: messages, comments: comments});
                }
            })
        }
    })
    // Message.find({})
    // .populate({name:"comments", model: "Comment"})
    // .exec(function(err, messages) {
    //     if(err) {
    //         console.log("error grabbing all messages");            
    //     }
    //     else {
    //         res.render("index", {messages: messages, comments: comments});       
    //     }
    // })
})
app.post("/message", function(req, res) {
    let newMessage = new Message(req.body);
    newMessage.save(function(err) {
        if(err) {
            console.log("error saving message");
        }
        else {
            res.redirect("/");
        }
    }) 
})
app.post("/comment/:id", function(req, res) {
    Message.findOne({_id: req.params.id}, function(err, message){
        let newComment = new Comment(req.body);
        newComment._message = message.id;
        newComment.save(function(err) {
            if(err) {
                console.log(err);
                console.log(message.id);
                console.log(message._id);
                console.log(newComment);                
                console.log("error saving comment");
            }
            else {            
                message.comments.push(newComment);
                message.save(function(err) {
                    if(err) {
                        console.log("error saving message with comment");
                    }
                    else {
                        res.redirect("/");
                    }
                })
            }
        }) 
    })
})

app.listen(6789, function() {
    console.log("listening on port 6789");
})