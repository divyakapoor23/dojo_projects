SELECT * FROM users
