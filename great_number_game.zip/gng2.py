from flask import Flask, render_template, session, request, redirect
import random 

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'

@app.route('/')
def num_game():
    if "number" not in session:
        session['number'] = random.randrange(1, 101)
    print session['number'] 
    return render_template('index2.html')

@app.route('/guess', methods=["POST"])
def guess(): 
    guess = int(request.form['guess'])
    print guess
    if session.get('number') == guess:
        session['message'] = "{} was the number".format(session['number'])
        print session['message']
        return render_template('index2.html', message=session['message'], reset=True)
    else:
        if session.get('number') > guess: 
            session['message'] = "{} is too low!!".format(guess)
            print session['message']
            return render_template('index2.html', message=session['message'], reset=False)
        else: 
            session['message'] = "{} is too high!".format(guess)
            print session['message']
            return render_template('index2.html', message=session['message'], reset=False)

@app.route('/reset')
def reset():
    session.pop('number')
    session.pop('message')
    return redirect('/')

app.run(debug=True)



